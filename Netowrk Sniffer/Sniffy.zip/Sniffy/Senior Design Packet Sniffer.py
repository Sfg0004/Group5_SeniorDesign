import dpkt
#import libpcap
import datetime
import socket	#Imported to convert IP form bytes to string
import pcapy
import select

#The goal of this program is to process network traffic, either from a pcap(generally) or live
#Future plans:
#Could have 2 sections, GUI and command line.
#Could write script to run at startup, and a refresh script every 5 seconds
#Future change: for basicData, ICMP-[ICMP message types]

#Basic structure holding the MAC addresses and the IP addresses involved in the message
class basicData:
	def __init__(self, packetNum, MAC_src, MAC_dst, IP_src, IP_dst, sPort, dPort, MSG_type, tcp_udp, time):
		self.packetNum = packetNum		#Saves the packet number of the packet
		self.MAC_src = MAC_src			#MAC address of the source
		self.MAC_dst = MAC_dst			#MAC address of the destination
		self.IP_src = IP_src			#IP source of the packet
		self.IP_dst = IP_dst			#IP destination of the packet
		self.sPort = sPort			#Saves the source port
		self.dPort = dPort			#Saves the destination port
		self.MSG_type = MSG_type		#Saves the type of messages, i.e. ARP-[request/reply], ICMP, ""
		self.tcp_udp = tcp_udp			#if tcp or udp, string matching "tcp" or "udp". Else, "" 
		self.time = time			#Timestamp of the packet

#Function to print the menu for the program
def printMenu():
	print("[1] Process a packet file")
	print("[2] Process packets live")
	#Could be used later when more options are available
	#print("[3]")
	#print("[4]")
	#print("[5]")
	
#Function to get the packet number as a string
def getPacketNumber():
	#Tries to open the conf file to find the current
	try:
		inputFile = open("sniffy.conf", 'r')		#Opens the configuration file
		#Loops through the entire file and locates the line containing the packet scan number
		for line in inputFile:
			#If the line contains "Packet_Number", then get the next packet number
			if "Packet_Number" in line:
				#Just in case there is an issue in string parsing, catch the issue
				try:
					#Finds the index of the number by parsing and stripping
					return ((line[(line.index('=')+2):]).strip())	#Strips leading and trailing whitespace, locates the packet number, and returns it as a string
				#Catches any error in string parsing
				except:
					return ""	#Returns an empty string to make the default save location not change
					
	#Catches if the file does not exist
	except FileNotFoundError:
		return ""	#Returns an empty string to make the default save location not change
	#Catches if there is a problem reading from the file
	except IOError:
		return ""	#Returns an empty string to make the default save location not change
	#Catches any otherissue
	except:
		return ""	#Returns an empty string to make the default save location not change

#Function to write the given list of packet headers to a file
def savePackets(packetsList, writeOption):
	outputFilename = "./Packet_Captures/Packet_Capture_" + getPacketNumber()		#Creates the outfile file name and gets the name of the next file
	outputfile = open(outputFilename, writeOption)       #Opens packetfile for writing
	#Loops through all saved packets and outputs the data stored in each class object
	for x in packetsList:
		outputfile.write("Packet: " + str(x.packetNum) + "\n")		#Stores the packet number of the packet
		outputfile.write("MAC src: " + str(x.MAC_src) + "\n")		#Stores the source MAC address of the packet
		outputfile.write("MAC dst: " + str(x.MAC_dst) + "\n")		#Stores the destination MAC address of the packet
		outputfile.write("IP src:  " + str(x.IP_src) + "\n")		#Stores the source IP of the packet
		outputfile.write("IP dst:  " + str(x.IP_dst) + "\n")		#Stores the destination IP of the packet
		outputfile.write("Src Port:  " + str(x.sPort) + "\n")		#Stores the source port of the packet
		outputfile.write("Dst Port:  " + str(x.dPort) + "\n")		#Stores the destination port of the packet
		outputfile.write("Type: " + str(x.MSG_type) + "\n")		#Stores what type of message the packet is
		outputfile.write("TCP/UDP " + str(x.tcp_udp) + "\n")		#Stores if the packet is TCP or UDP
		outputfile.write("Time: " + str(x.time) + "\n\n")		#Stores the tiestamp of the packet
	outputfile.close()	#Closes the file

#Main function to run setting up the packet sniffer
def main():
	menuOption = 1	#Initial value so loop enters
	#Loops until the user does not enter 1 or 2
	while menuOption == 1 or menuOption == 2:
		printMenu()	#Prints the menu
		#Gets the user's input
		try:
			menuOption = int(input("Enter menu option: "))
		#Catches if the user enters invalid input
		except ValueError:
			print("\nInvalid option.\n\n")		#Informs the user of thier invalid choice
			#Restarts and terminates
			main()		#Restarts the program
			exit()		#Terminates for safety
		#If the user wants to process a packet file...
		if menuOption == 1:
			#Gets the name of the packet file from the user
			filename = str(input("Enter the file name or the path to the file: "))
			#Processes the packet file
			processPacketFromFile(filename)
		#If the user wants to process a packets live...
		elif menuOption == 2:
			#Gets the interface to capture packets on
			interface = str(input("Enter the interface to capture on: "))
			#Processes the packets live
			processPacketsLive(interface)
		#Else, termiate as requested by the user.
		else:
			print("Pleasure capturing for you.")
			

#Function to process a pcap file into a block
def processPacketFromFile(filename):
	#Tries to open the input packet file the user's input
	try:
		inputPackets = open(filename, 'rb')		#Reads the bytes in the pcap file
	#Catches if the packet file does not exist
	except FileNotFoundError:
		print("\nFile does not exist. \n\n")		#Informs the user of thier invalid choice
		#Restarts and terminates
		main()		#Restarts the program
		exit()		#Terminates for safety
	#Catches if the packet file encounters an error upon opening
	except IOError:
		print("\nError opening file. \n\n")		#Informs the user of thier invalid choice
		#Restarts and terminates
		main()		#Restarts the program
		exit()		#Terminates for safety
	#Else, if there is another issue, terminate
	except:
		print("\nSomething went wrong when opening the file. Terminating...")
		exit()		#Terminates for safety
		
	packets = dpkt.pcap.Reader(inputPackets)	#Uses dpkt to process packets
	packetsList = []		#List to contain classes containing the required information from the packets
	i = 0	#Packet intex number
	
	#Loops through all packets and processes important information
	#Currently, setup for ipv4, ipv6 is a planned version
	#ts is the timestamp in ms since 1970
	#buf is the packet's actual data
	for ts, buf in packets:
		i = i + 1	#Increments the packet number
		timestmp = datetime.datetime.utcfromtimestamp(ts)	#Converts the timestamp to human-readable form
		ethernetLayer = dpkt.ethernet.Ethernet(buf)		#Convers the buffer into the ethernet Layer
		#Checks what data is inside the ethernet packet
		#If IP packet, process it as such
		if isinstance(ethernetLayer.data, dpkt.ip.IP):
			ipMessage = ethernetLayer.data	#Saves the paylod of the ethernet layer
			socket.inet_ntoa(ipMessage.src)#or dst
			#Checks if the message is an ICMP packet, process as such
			if isinstance(ipMessage.data, dpkt.icmp.ICMP):
				icmpMessage = ipMessage.data	#Saves the icmp message data
				#Converts the ethernet MAC source and destination bytes to strings, saves the IP source and target IP, marks the source and destination ports, no message type, TCP, and the timestamp of the packet
				messageDataType = basicData(i, (':'.join(f'{b:02x}' for b in ethernetLayer.src)), (':'.join(f'{b:02x}' for b in ethernetLayer.dst)), (socket.inet_ntoa(ipMessage.src)), socket.inet_ntoa(ipMessage.dst), -1, -1, "ICMP", "", timestmp)
				packetsList.append(messageDataType)	#Appends the processed packet's data to the list of packets			
			
			#Checks if the next layer of the message is TCP. If so, process as such
			elif isinstance(ipMessage.data, dpkt.tcp.TCP):
				tcpMessage = ipMessage.data	#Saves the TCP message data
				#Converts the ethernet MAC source and destination bytes to strings, saves the IP source and target IP, marks the source and destination ports, no message type, TCP, and the timestamp of the packet
				messageDataType = basicData(i, (':'.join(f'{b:02x}' for b in ethernetLayer.src)), (':'.join(f'{b:02x}' for b in ethernetLayer.dst)), (socket.inet_ntoa(ipMessage.src)), socket.inet_ntoa(ipMessage.dst), int(tcpMessage.sport), int(tcpMessage.dport), "", "tcp", timestmp)
				packetsList.append(messageDataType)	#Appends the processed packet's data to the list of packets
			
			#Checks if the next layer of the message is UDP. If so, process as such
			elif isinstance(ipMessage.data, dpkt.udp.UDP):
				udpMessage = ipMessage.data	#Saves the UDP message data
				#Converts the ethernet MAC source and destination bytes to strings, saves the IP source and target IP, marks the source and destination ports, no message type, UDP, and the timestamp of the packet
				messageDataType = basicData(i, (':'.join(f'{b:02x}' for b in ethernetLayer.src)), (':'.join(f'{b:02x}' for b in ethernetLayer.dst)), (socket.inet_ntoa(ipMessage.src)), socket.inet_ntoa(ipMessage.dst), int(udpMessage.sport), int(udpMessage.dport), "", "udp", timestmp)
				packetsList.append(messageDataType)	#Appends the processed packet's data to the list of packets
				
				
		#If the packet is an ARP message, save the data from the message
		elif isinstance(ethernetLayer.data, dpkt.arp.ARP):
			#Strips the ethernet layer and saves the ARP layer
			arpMessage = ethernetLayer.data
			#If the ARP message is an ARP request, process as such
			if arpMessage.op == 1:
				#Converts the ethernet MAC source and destination bytes to strings, saves the arp source and target IP, marks no source or destination ports, the message type, the lack of TCP or UDP, and the timestamp of the packet.
				messageDataType = basicData(i, (':'.join(f'{b:02x}' for b in ethernetLayer.src)), (':'.join(f'{b:02x}' for b in ethernetLayer.dst)), (socket.inet_ntoa(arpMessage.spa)), (socket.inet_ntoa(arpMessage.tpa)), -1, -1, "ARP-request", "", timestmp)
				packetsList.append(messageDataType)	#Appends the processed packet's data to the list of packets
			#If the ARP message is an ARP reply, process as such
			elif arpMessage.op == 2:
				#Converts the ethernet MAC source and destination bytes to strings, saves the arp source and target IP, marks no source or destination ports, the message type, the lack of TCP or UDP, and the timestamp of the packet
				messageDataType = basicData(i, (':'.join(f'{b:02x}' for b in ethernetLayer.src)), (':'.join(f'{b:02x}' for b in ethernetLayer.dst)), (socket.inet_ntoa(arpMessage.spa)), (socket.inet_ntoa(arpMessage.tpa)), -1, -1, "ARP-reply", "", timestmp)
				packetsList.append(messageDataType)	#Appends the processed packet's data to the list of packets

	print("\nExamined " + str(i) + " packets")
	print("Saving " + str(len(packetsList)) + " packets\n")
	#Once complete with processing the pcap file, save the given data to a file
	savePackets(packetsList, 'w')
	
#Function to process the packets
def packet_handler(headerData, packetData, packetNumber):
	timestamp = headerData.getts()		#Gets the timestamp from the packet header
	#Sends the packet data, the timestamp, and the packet number from the calling function
	processCapturedPacket(packetData, timestamp[0] + timestamp[1] / 1000000, packetNumber)	#Process packet data

#Function to process a pcap file from a live capture
def processPacketsLive(interface):
	#Tries to read packets
	try:
		capture = pcapy.open_live(interface, 65536, True, 100)	#Opens to capture packets on the interface
		packetNumber = 0	#Packet capture number
		#Loops forever to capture packets
		while True:
			#fileDescriptor = capture.getfd()
			#readableInfo, writableInfo, executableInfo = select.select([fileDescriptor], [], [], 0.1)
			
			#if capture in readableInfo:
				packetNumber = packetNumber + 1		#Increment the packet number
				print("packetNumber = " + str(packetNumber))
				headerData, packetData = capture.next()		#Saves the information from the packet capture
				packet_handler(headerData, packetData, packetNumber)		#Sends the packets to the processing system
		
	#Catches the issue that results from "Ctrl + C", showing that the user wants to stop reading packets
	except KeyboardInterrupt:
		print("Packet capture stopped\n")
	#Catches any other issue
	except:
		print("An issue occurred when reading packets from interface " + str(interface))	#Informs the user of the issue on the interface
		exit()	#Terminates

#Function to process the given packet.
#Very similiar to processing packets from a file, but different based on live packets being sent live
def processCapturedPacket(packetData, timestamp, packetNumber):
	timestamp = datetime.datetime.utcfromtimestamp(timestamp)	#Converts the timestamp to human-readable form
	ethernetLayer = dpkt.ethernet.Ethernet(packetData)		#Convers the buffer into the ethernet Layer
	#Checks what data is inside the ethernet packet
	#If IP packet, process it as such
	if isinstance(ethernetLayer.data, dpkt.ip.IP):
		ipMessage = ethernetLayer.data	#Saves the paylod of the ethernet layer
		socket.inet_ntoa(ipMessage.src)#or dst
		#Checks if the message is an ICMP packet, process as such
		if isinstance(ipMessage.data, dpkt.icmp.ICMP):
			icmpMessage = ipMessage.data	#Saves the icmp message data
			#Converts the ethernet MAC source and destination bytes to strings, saves the IP source and target IP, marks the source and destination ports, no message type, TCP, and the timestamp of the packet
			messageDataType = basicData(packetNumber, (':'.join(f'{b:02x}' for b in ethernetLayer.src)), (':'.join(f'{b:02x}' for b in ethernetLayer.dst)), (socket.inet_ntoa(ipMessage.src)), socket.inet_ntoa(ipMessage.dst), -1, -1, "ICMP", "", timestamp)
		
		#Checks if the next layer of the message is TCP. If so, process as such
		elif isinstance(ipMessage.data, dpkt.tcp.TCP):
			tcpMessage = ipMessage.data	#Saves the TCP message data
			#Converts the ethernet MAC source and destination bytes to strings, saves the IP source and target IP, marks the source and destination ports, no message type, TCP, and the timestamp of the packet
			messageDataType = basicData(packetNumber, (':'.join(f'{b:02x}' for b in ethernetLayer.src)), (':'.join(f'{b:02x}' for b in ethernetLayer.dst)), (socket.inet_ntoa(ipMessage.src)), socket.inet_ntoa(ipMessage.dst), int(tcpMessage.sport), int(tcpMessage.dport), "", "tcp", timestamp)
			
		#Checks if the next layer of the message is UDP. If so, process as such
		elif isinstance(ipMessage.data, dpkt.udp.UDP):
			udpMessage = ipMessage.data	#Saves the UDP message data
			#Converts the ethernet MAC source and destination bytes to strings, saves the IP source and target IP, marks the source and destination ports, no message type, UDP, and the timestamp of the packet
			messageDataType = basicData(packetNumber, (':'.join(f'{b:02x}' for b in ethernetLayer.src)), (':'.join(f'{b:02x}' for b in ethernetLayer.dst)), (socket.inet_ntoa(ipMessage.src)), socket.inet_ntoa(ipMessage.dst), int(udpMessage.sport), int(udpMessage.dport), "", "udp", timestamp)				
				
	#If the packet is an ARP message, save the data from the message
	elif isinstance(ethernetLayer.data, dpkt.arp.ARP):
		#Strips the ethernet layer and saves the ARP layer
		arpMessage = ethernetLayer.data
		#If the ARP message is an ARP request, process as such
		if arpMessage.op == 1:
			#Converts the ethernet MAC source and destination bytes to strings, saves the arp source and target IP, marks no source or destination ports, the message type, the lack of TCP or UDP, and the timestamp of the packet.
			messageDataType = basicData(packetNumber, (':'.join(f'{b:02x}' for b in ethernetLayer.src)), (':'.join(f'{b:02x}' for b in ethernetLayer.dst)), (socket.inet_ntoa(arpMessage.spa)), (socket.inet_ntoa(arpMessage.tpa)), -1, -1, "ARP-request", "", timestamp)
		#If the ARP message is an ARP reply, process as such
		elif arpMessage.op == 2:
			#Converts the ethernet MAC source and destination bytes to strings, saves the arp source and target IP, marks no source or destination ports, the message type, the lack of TCP or UDP, and the timestamp of the packet
			messageDataType = basicData(packetNumber, (':'.join(f'{b:02x}' for b in ethernetLayer.src)), (':'.join(f'{b:02x}' for b in ethernetLayer.dst)), (socket.inet_ntoa(arpMessage.spa)), (socket.inet_ntoa(arpMessage.tpa)), -1, -1, "ARP-reply", "", timestamp)
	
	#Once complete with processing the packet, try to save the given data to a file
	try:
		outputFilename = "./Packet_Captures/Packet_Capture_" + getPacketNumber()	#Creates the outfile file name and gets the name of the next file
		outputfile = open(outputFilename, 'a')       #Opens packetfile for writing, appending packet header data to the end of the file
		outputfile.write("Packet: " + str(messageDataType.packetNum) + "\n")		#Stores the packet number of the packet
		outputfile.write("MAC src: " + str(messageDataType.MAC_src) + "\n")		#Stores the source MAC address of the packet
		outputfile.write("MAC dst: " + str(messageDataType.MAC_dst) + "\n")		#Stores the destination MAC address of the packet
		outputfile.write("IP src:  " + str(messageDataType.IP_src) + "\n")		#Stores the source IP of the packet
		outputfile.write("IP dst:  " + str(messageDataType.IP_dst) + "\n")		#Stores the destination IP of the packet
		outputfile.write("Src Port:  " + str(messageDataType.sPort) + "\n")		#Stores the source port of the packet
		outputfile.write("Dst Port:  " + str(messageDataType.dPort) + "\n")		#Stores the destination port of the packet
		outputfile.write("Type: " + str(messageDataType.MSG_type) + "\n")		#Stores what type of message the packet is
		outputfile.write("TCP/UDP " + str(messageDataType.tcp_udp) + "\n")		#Stores if the packet is TCP or UDP
		outputfile.write("Time: " + str(messageDataType.time) + "\n\n")			#Stores the tiestamp of the packet
		outputfile.close()	#Closes the file
	#Catches if the packet has not met the criteria
	except NameError:
		pass	#Do nothing as not necessary

main()
